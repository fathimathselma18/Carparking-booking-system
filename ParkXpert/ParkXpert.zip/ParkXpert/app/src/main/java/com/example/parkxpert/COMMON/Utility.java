package com.example.parkxpert.COMMON;

public class Utility {

    public static String ip="192.168.233.15";

    public static String SERVERUrl="http://"+ip.trim()+":8080/parkXpertServer/Android/parkXpert_serverController.jsp";


}


